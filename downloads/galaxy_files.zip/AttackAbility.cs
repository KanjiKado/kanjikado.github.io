﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ScumbagGalaxy
{
	/// <summary>An ability that modifies a unit's hitpoints</summary>
    class AttackAbility : Ability
    {
        int damage;
        public int Damage { get { return damage; }  }//How many hitpoints affected units lose (positive) or gain (negative)

		
		/// <summary>An ability that modifies a unit's hitpoints</summary>
        public AttackAbility(int damage, int range, int radius, int cost, List<Buff> buffs = null) : base(range, radius, cost)
        {
            //setup damage
            this.damage = damage;

            //register any buffs
            if(buffs!=null)foreach(Buff b in buffs) RegisterBuff(b);
        }
		
		/// <summary>
		/// Damages and applies any registered buffs to the unit paramater.
		/// </summary>
        override internal void ApplyTo(LiveUnit u)
        {
			base.ApplyTo (u);
            u.ApplyDamage(damage);
        }
    }
}
