﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ScumbagGalaxy
{
    //Stores additional information required to allow the unit to "live" on the board
    public class LiveUnit : Unit
    {
        //UI object representing this unit
        public UI.UIUnits.UIUnit sprite;

        //Movement status
        public bool hasMoved, hasAttacked;

        //int 
        int currentHealth = 0;
        public int CurrentHealth { get { return currentHealth; } }
        float currentHealsTaken = 0;
        int movesleft = 0;
        string spritePath = "";
        string portraitpath = "";
        public string SpritePath { get { return spritePath; } set { spritePath = value; } }
        public string PortraitPath { get { return portraitpath; } set { portraitpath = value; } }
        public int MovesLeft { get { return movesleft; } set { movesleft = value; } }
        //byte
        OwnerPlayer ownerPlayer;
        public OwnerPlayer OwnerPlayer { get { return ownerPlayer; } }

        //buff
        Dictionary<String, Buff> buffs;//string-based dictionary
        public List<Buff> Buffs { get { return buffs.Values.ToList(); } }
        public LiveUnit(int maxHealth)
        {
            this.maxHealth = maxHealth;
            currentHealth = maxHealth;
            currentHealsTaken = baseHealsTaken;
            this.Abilities = new List<Ability>();
            this.buffs = new Dictionary<string, Buff>();

            //The unit has moved and has attacked by default
            this.hasMoved = true;
            this.hasAttacked = true;
        }
        public void ApplyDamage(int damage)
        {
            if (damage <= 0)
            {
                //heal functionality
                float multiplier = currentHealsTaken + Utils.AsPercent(StrengthOfBuffType(BuffType.FlatHealingRecieved));
                currentHealth -= (int)(damage * multiplier);
            } else
            {
                float damageModifier = 1;// + Utils.AsPercent(StrengthOfBuffType(BuffType.FlatDamageRecieved));
                currentHealth -= (int)(damage * damageModifier);
            }
            currentHealth = Math.Max(Math.Min(currentHealth, maxHealth), 0);//increased max health buff requires special functionality here.
        }

        public int StrengthOfBuffType(BuffType type)
        {
            int total = 0;
            foreach (Buff b in buffs.Values)
            {
                if (b.Type == type)
                    total += b.Strength;
            }
            return total;
        }

        public bool ContainsBuffType(BuffType type)
        {
            //bask in the glory of my linear search
            foreach (Buff b in buffs.Values)
            {
                if (b.Type == type)
                    return true;
            }
            return false;
        }
        public void StackBuff(Buff b)
        {
            //check for instant buffs (these immediatley expire so don't add them)
            if (b.Type == BuffType.InstantDamage)
            {
                ApplyDamage(b.Strength);
                return;
            }
            if (b.Type == BuffType.InstantHealsTaken)
            {
                currentHealsTaken += ((float)b.Strength) / 100.0f;//TODO: ensure this does float math

                //clamp within
                if (currentHealsTaken < Unit.MIN_HEALS_TAKEN)
                    currentHealsTaken = Unit.MIN_HEALS_TAKEN;
                return;
            }

            //search for buff
            if (!buffs.ContainsKey(b.Title))
            {
                //case: not contained
                buffs.Add(b.Title, b);

                OnBuffApplied(b);
                return;
            }
            //else

            //housekeeping for if they don't have the same strength
            OnBuffExpired(buffs[b.Title]);
            OnBuffApplied(b);

            //update buff
            if (buffs[b.Title].DoesStack)
            {
                int temp = buffs[b.Title].RemainingDuration;
                buffs[b.Title] = b;
                buffs[b.Title].RemainingDuration += temp;
            } else
            {
                //if name same: replace existing buff
                buffs[b.Title] = b;
            }
        }
        public void DecrementBuffs()
        {
            List<string> keysToRemove = new List<string>();
            foreach (Buff b in buffs.Values)
            {
                b.RemainingDuration--;
                if (b.RemainingDuration <= 0)
                    keysToRemove.Add(b.Title);
            }
            foreach (string key in keysToRemove)
            {
                OnBuffExpired(buffs[key]);
                buffs.Remove(key);
            }
        }

        //check for flat buffs
        private void OnBuffApplied(Buff b, bool applied = true)
        {
            //whether we're adding or subtracting
            int amt = b.Strength * (applied ? 1 : -1);
            
            switch(b.Type)
            {
                case BuffType.FlatCriticalDamage: critDamage += amt; break;
                case BuffType.FlatCriticalChance: critChance += amt; break;
                case BuffType.FlatHealsTaken: currentHealsTaken += amt; break;
                case BuffType.FlatMaxHealth: maxHealth += amt; currentHealth = Math.Min(maxHealth, currentHealth); break;
                case BuffType.FlatMovement: speed += amt; movesleft += (speed-movesleft); break;
            }
        }
        private void OnBuffExpired(Buff b)
        {
            OnBuffApplied(b, false);
        }
    }
}